
# Incident Management
The first goal of the incident management process is to restore a normal service operation as quickly as possible and to minimize the impact on business operations, thus ensuring that the best possible levels of service quality and availability are maintained. 'Normal service operation' is defined here as service operation within service-level agreement (SLA).

**Cloud Automation Engineering** will serve as a single support team made up of Planning, Engineering, and Operations that provides support for the vRA/vRO platform. The support group for this team, within the incident management system, is **Global Cloud Automation Engineering**.  

## Table of Contents
[Reporting Incidents](#reporting-incidents) 

[On-call Support for Critical Incidents](#oncall)

[Service Level Agreement (SLA)](#SLA)

[Incident Support Model](#incident-model)

[SACM Requirements](#sacm)

[Incident Management KPIs](#kpi)

[Incident Management Desk Procedures](#desk-procedures)
   - [Incident Communication Plan](#communication)
   - [Gloabl Incident Management Process (GIM)](#GIM)
   - [Incident Escalation Matrix](#escalate)
	
	

<a name="reporting-incidents"></a>
## Reporting Incidents
Typically, Service teams utilizing the vRA/vRO platform will be the first to raise incidents in case of any failures in the platform.  However, End-customers can also submit incidents to the platform team in case the portal is down.

To report an incident related to vRA and vRO use the [Report Application Incident](http://www.request.ford.com/RequestCenter/myservices/navigate.do?query=orderform&sid=294&layout=&) form and search on "vrealize".  For **critical incidents**, which are ONLY for production outages, please call ITSD or Skype at gsdictrl@ford.com.

**Issues submitted via email will have no guarantee of being read nor completed.**

<a name="oncall"></a>
## Oncall Support for Critical Incidents

Cloud Automation Engineering team members may be contacted via [CMOS](http://www.tcs.ford.com/cmos/cmos.asp) for critical incidents.  The call list name is **VRA VRO - GLOBAL CLOUD AUTOMATION ENGINEERING** and can be found under ITO PRODUCT SERVICE SUPPORT -> CLOUD AUTOMATION.

For weekend critical tickets, which are ONLY for production outages, you may call ITSD or Skype at gsdictrl@ford.com.  ITSD will then contact the On-call Engineer as per CMOS schedule.

<a name="SLA"></a>
## Service Level Agreement (SLA)
| Priority | TRT* | Coverage| Comments|
| :--- | :--- |:--- |  :--- | 
| Critical| 2 hours |24/7 | Weekends - Oncall Support|
| High | 24 hours (1 Day)|24/5 (Mon-Fri)|
| Medium | 7 Days|24/5 (Mon-Fri)|
| Low |28 Days |24/5 (Mon-Fri)|

*TRT - Target Resolution Time

<a name="common"></a>
## Common Incidents / Failures
| Application | Issues|
| :--- | :--- |
| vRealize Automation (vRA)| The vRA portal is down|
|| Lost access to portal|
|| VM provisioning is failed|
|| Blueprint is having some issues|
|| Day 2 VM actions are not functioning properly|
|| Business-group reservation is full|
|| VM Cloning issue|
|vRealize Orchestrator (vRO)| vRO Workflow is failed|
|| External integration service is failed (eg. BMC, AD, NaaS, etc.,)|
|| Lost access to vRO|

<a name="incident-model"></a>

## Incident Support Model

![alt text](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/Images/Incident%20Flow.png)

<a name="sacm"></a>
## SACM Requirements
(Coming soon)


<a name="kpi"></a>
## Incident Management KPIs

### KPI: % of incident tickets resolved within TRT
#### Target
Critcal -> at least 80%

High -> at least 90%

Medium/Low -> at least 85% 

#### Measurment
Number of Critical/High/Medium/Low tickets resolved within TRT 

Divided By 

Total number of Critical/High/Medium/Low tickets

<a name="desk-procedures"></a>
## Incident Management Desk Procedures

<a name="communication"></a>
### Outage Communication Plan

|   Bulkmail List   | Purpose| Links to Subscribe|
|----------|----------|----------|
|ITO_NG_CLOUD_AUTOMATION@bulkmail.ford.com|Scheduled maintenance activities|[ITO_NG_CLOUD_AUTOMATION](http://bulkmail.ford.com/~BULKMAIL/Subscriptions.cgi?list=Z0074207)|
|IT_ADV_ALL@bulkmail.ford.com|All Critical and High Incidents and Major Outages|[IT_ADV_ALL](http://bulkmail.ford.com/~BULKMAIL/Subscriptions.cgi?list=Z0028997) |
|IT_ADV_GLOBAL@bulkmail.ford.com| All types of incidents & Scheduled maintenance activities|[IT_ADV_GLOBAL](http://bulkmail.ford.com/~BULKMAIL/Subscriptions.cgi?list=Z0027085)

#### How to send out an IT advisory
Our change communication is aligned with Global IT advisory process. Please visit the site at [IT Advisory](https://it1.spt.ford.com/sites/ITAdvisorySite/SitePages/Home.aspx)  for more information. This site also has training materials on how to create, send and manage an IT advisory.

[Sample Communication](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/processes/document/ITO%20Cloud%20Automation%20%20%20vRA%20Portal%20%20Active%20Directory%20Sync%20Issue.oft)

[Sample IT Advisory](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/processes/document/IT%20Advisory%2055520%20-%20Medium%20-%20vRealize%20Automation%20-%20vRA%20Portal%20-%20vra.cloud.ford.com%20-%20Final%20-%20Root%20Cause%20Identified%20-%20ITADVSMG.oft)
<a name="GIM"></a>
### Gloabl Incident Management Process (GIM)
https://it1.spt.ford.com/sites/ITAdvisorySite/SitePages/Home.aspx

<a name="escalate"></a>
### Incident Escalation Matrix ###
Incident Escalation Matrix for Cloud Automation Engineering provides an opportunity for service owners and customers to escalate incidents to next level in case the assigned engineer's response or resolution is not satisfactory. Contacts can be found at [here](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/processes/contacts_ticketing_info.MD)
  
|	Ticket Priority	|	Category Definition |	Acknowledge Within	|	Begin Troubleshooting	|	Client Updates | Escalation Expectations |
|---------------|---------------|-------------|---------|------------------|-----------------|
|	Critical	|	Core Business Function or system is down or (potential) loss of mission critical data - users cannot do their job	|	Immediately to 60 minutes	|	Immediately to 60 minutes	|	60 Minutes Update | 75 Minutes - Product Owner / 120 Minutes - Senior Manager |
|	High	|	Productivity Impact or non-core activities impacted. Users can do job with increased workload or can do part of their job	|	60 minutes	|	Within 1-2 Hours	|	8 Hours Updates | 4 Hours - Product Owner / 24 Hours - Senior Manager |
|	Medium	|	Interferes with normal completion of work but a sustainable workaround exists - either manual or automated	|	4-8 Hours	|	Within 1 Business Day, or per change control |	Notification weekly until completion | 8 Hours - Product Owner / 24 Hours - Senior Manager |
|	Low	|	Minor inconvenience - impacts infrequent tasks or user can live with the issue with minimal impact	|	1 Business Day	|	Variable |	Notification weekly until completion | 48 Hours - Product Owner / 1 Week - Senior Manager |

