
## Request Fulfilment
Request fulfillment is the process responsible for managing the lifecycle of all service requests from the users. Request fulfillment is all about making sure customers have easy access to the IT services they need.

All requests and questions should be submitted to the Global Cloud Automation Engineering group via Request Center tickets. **Requests submitted via email will have no guarantee of being read nor completed**

|Request Center Tool | Suport Group Queue|
| :--- | :--- | 
|https://www.request.ford.com/| Global Cloud Automation Engineering|



- [Request Fulfilment](#request-fulfilment)
	- [Service Level Agreement (SLA)](#service-level-agreement-sla)
	- [Common Requests](#common-requests)
	- [How to submit a request?](#how-to-submit-a-request)


<a name="SLA"></a>
### Service Level Agreement (SLA) ###
Usually 5 business days. All priority requests should be worked with Product owners for immediate attention.

Note: Some of the requests may take more time than the defined SLA and such requests will be discussed and reviewed with requestor and worked by team through Agile sprints.


<a name="common"></a>
### Common Requests ###
- vRA / vRO Access requests
- General queries
- New Features
- Architecture enhancements

<a name="how"></a>
### How to submit a request? ###
Submitting a new request for Platform related services in Request Center, below procedures to be followed:

|Application Search | Application Name|
| :--- | :--- | 
|vra|vRealize Automation|
|vro|vRealize Orchestrator|

1. Go to www.request.ford.com 
2. Click on User Admin Customer Support link under Applications. 
3. Under the "Application Information" Section, select Application by Application Name. 
4. In the "Application Search Criteria" box, type "vra" or "vro" and then click on Search button. 
5. Go to the Application name drop down and select Application.
6. Fill out the "Request Information" section. 
7. Click on Submit button.

