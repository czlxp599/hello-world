# Change Process for vRA/vRO

**Background**
To provide standard procedure for change process in vRA/vRO which can be followed by members of vRA/vRO operations

**Purpose**
This document will provide detailed instructions on how to track changes which is happening in vRA/vRO platform


**Change Window**

*Standard*
- Change that is frequently requested, easy to do, low risk, no lead time & approval required

*Normal*
- Have minimum lead time, which requires review, planning, scheduling and approval(s) before implementation

*Expedited*
- Changes is requested earlier than minimum lead time
- Requires review, planning, scheduling and approval(s) before implementation

*Emergency*
- Changes initiated to mitigate or prevent an incident with approval(s)

*Latent*
- Used when the Emergency process could not be followed and the change has already been implemented
- Change record must be created within a certain time limit after implementation and requires post implementation approval.


## Change Approval Board

- Proper approval is required before perfoming any changes in vRA/vRO platform , based on change priorities




| Change class |Notification Period/Lead time| Notify |Approval required|Coordinator|Implementor|Validator  |
|:------------:|:---------------------------:|:-------|:---------------:|:---------:|:---------:|:---------:|
| Standard     |    0 days                   |        |     jvansic6    | Operations|Engineering|Engineering|
|  Normal      |    10 days                  |        |     vnachimu    |           |           |           |
| Expedited    |    None                     |        |     jvansic6    |           |           |           |
| Emergency    |    None                     |        |    sjoshi16     |           |           |           |
|  Latent      |    None                     |        |     jvansic6    |           |           |           |




## Types of changes

- Version Upgrade
- OS Patch
- Security related patch
- Break-Fix: A Change was implemented during an incident where emergency process could not be followed (i.e. change request is recorded post-implementation)

### *Test Plan*

1. Goto change repo
1. Identify change class which is to be implemented to vRA/vRO platform
1. Edit Approval Board with valid inputs such as change class , Lead time , Notify, Approval , coordinator , Implementor, Validator
1. Create PR with proper approval based on change class
1. Once PR is approved , update release tab with version tag
1. Implement changes to environment

### *Change Process*
Each change scenario has to follow this steps to interact with Github

For eg:

Usecase 
Version Upgrade:

- Clone or fork change repository
- Create a change branch
- Upload the changes which is going to incorporate in vRA/vRO platform
- git add . ; git commit -m "describe your changes"
- git commit -m "describe your feature" (just to be sure you didn't miss anything)
- git push origin
- Create a pull request
- Repository MAINTAINERS or APPROVERS will review the pull request, comment, vote, and merge accepted changes.
- Update release tab with changes which is going to take place in environment and version tag
- Implement changes to environment





