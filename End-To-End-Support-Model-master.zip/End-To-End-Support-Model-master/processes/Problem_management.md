
# Problem Management
The purpose of problem management is to manage the lifecycle of all problems from first identification through further investigation, documentation and eventual removal. Problem management seeks to minimize the adverse impact of incidents and problems on the business that are caused by underlying errors within IT, and to proactively prevent recurrence of incidents related to these errors.

## Problem Management System

| Tool | Support Group Name | Scope| Co-ordinators / Contacts|
| :--- | :--- |:--- | :--- | 
| BMC | Global Cloud Automation Engineering| Platform | jvansic6, sjoshi16, vnachimu
| Rally-Defects| Cloud Automation Engineering| Development|sjoshi16|

## Problem Management criteria
The Problem management is thought of as a reactive process in that it is invoked after incidents have occurred, but it is actually proactive, since its goal is to ensure that incidents do not recur in the future, or if they do, to minimize their impact.

Team raises a defect or problem record for an incident when

- The root cause is unknown
- The root cause is known and only workaround is provided
- The impact is huge and financial loss
- Proactive monitoring or Trend Analysis failures


## Problem Management LifeCycle
Both BMC and Rally systems has its own Lifecycle states.

When the problem or defect reaches at "Resolution State", team will initiate the release or change process to rollout the permanent resolution in Infrastructure or Application to close the problem or defect.

## Problem Prioritization
Product owners work with Requestor and review the impact and urgency of the defect or problem before it is assigned to an Engineer to work on. The progression of the problem or defect is constantly updated to the requestor.







