## External Integration Services
This document describes various external integration services, contacts in the case of failures and monitoring requirements.

## Table of Contents

[vRO External Services](#vroext)

[Monitoring Requirements](#monitoring)
   - [Proactive Monitoring](#proactive)
   - [Reactive Monitoring](#reactive)

[External Integration Services Endpoints](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/monitoring/External_Intergation_Services_Endpoints.md)

<a name="vroext"></a>
### vRO External Services
vRealize Orchestrator (vRO) helps us to integrate tools and technologies that connects various applications, systems, repositories, and IT environments for the real-time exchange of data and processes. Once combined, the integrated services can then be accessed by multiple devices over a network.

With the Orchestrator plug-ins, we can access and control external technologies and applications. Exposing an external technology in an Orchestrator plug-in lets you incorporate objects and functions in workflows and run workflows on the objects of that external technology. 

**The external technologies that you access by using plug-ins include virtualization management tools, email systems, databases, directory services, and remote control interfaces.**

<a name="monitoring"></a>
## Monitoring Requirements
<a name="proactive"></a>
### Proactive Monitoring
There is no Out-of-the-Box solution from VMware, which can do proactive monitoring of vRealize orchestrator including if all endpoints are there and available, plugins working etc.

When out-of-the-box solution falls short, a custom solution may be just what we are looking for. Off the start, you may be intimidated by the thought of custom code. 

#### Pitfalls

- **Custom code or modifying source code.** A solution made of a bunch of custom code written directly into out-of-the-box software is very sensitive and difficult to maintain. Upgrades or changes to the packaged software will often override the customization, meaning it will need to be rebuilt again and again. And the custom component is not maintained by the packaged software’s provider, meaning it’s on you to fix any problems.

- **Overbuilding.** It can be tempting to create a custom component for every feature, even if it could be handled just as well, or even better, by a less expensive out-of-the-box solution. This leads to unnecessarily complex systems that are difficult to use and expensive to maintain

***The important thing we would consider is that this sort of things counts as potentially wasted cycles and/or could contribute to system slow-down if for example the test workflows started to occupy too much of the server resources when running. It would really depend on how many such workflows you were planning to have.***


### Custom Code Solutions
Take an advantage of APIs to create stable customizations, enhancements, and integrations without changing the code of any packaged software that may be included.

##### Intergration Services Monitoring
- Create a workflow which does a simple query on the endpoint content (e.g., for RESTHost, do a simple GET request). The workflow would need to throw appropriate errors in the case of any failures or bad result. You could use the SMTP capability to notify you with failure details

- Schedule the workflow to run in out of hours (like a hourly basis)

- Do one workflow per endpoint, or more if specific data from endpoints require it

##### Blueprints Monitoring
- Build a "canary" workflow for VM provisioning in vRA (provision the same VM every few hours to prove system is working). 
  
- Have an XaaS overlay on the vRA IaaS Catalog items. Create a static config (name, IP, etc) for the canary VM and then have a schedule task just make requests for it and then self-schedule again for an hour later when the IaaS request had completed.

#### Scheduler
- You could leverage vRO scheduler workflow-element to schedule, pause and run workflows regularly.
- Include monitoring workflow of each endpoint in blueprints to make sure all services are healthy before the actual provisioning starts
- You can use Jenkins (vRA/vRO service pipeline) to run monitoring workflows for each release / code promotion.
  
<a name="reactive"></a>
### Reactive Monitoring
These type of monitoring will help us to detect the errors and logs once the failure happens.

#### Accessing HTML5 Orchestrator Dashboard in vRealize Automation 7.4
In vRealize Orchestrator, new feature is a really clean dashboard portal for vRealize Orchestrator, in full HTML5/ClarityUI.

#### vRealize Automation/Orchestrator Management Packs
Both vRealize Operations Manager (vROps) and Log Insight (vRLI) come with management packs for vRealize Automation and Orchestrator. Using this out of the box feature, we can monitor the failures and errors of workflows that are associated with external integration services

