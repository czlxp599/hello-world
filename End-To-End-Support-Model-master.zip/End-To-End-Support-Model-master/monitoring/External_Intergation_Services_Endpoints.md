# External Integration Services Endpoints

## Table of Contents

[Services Contacts and Incident ticketing procedures](#contacts)

[Endpoints Inventory](#prod)
- [PROD](#prod)
- [PrePROD](#preprod)

<a name="contacts"></a>
### Services Contacts and Incident ticketing procedures

| Service Name  | Service Owner / Contacts | Ticketing Procedure|
|----------|---------|---------|
| Active Directory |mmahajan|[Click Here](https://www.cns.ford.com/AD/TICKET_INFO/)|
|API Connect|myao|TBD|
| BMC - SACM|bviswach|[Click Here](http://www.request.ford.com/RequestCenter/myservices/navigate.do?query=orderform&sid=294&layout=&) and application search - BMC NGDC Service Desk (For escalations - Ford_MS@bmc.com, jlokesh4@ford.com |
| Chhef/Habitat|kcardwel|TBD|
|gMSA|mmahajan|[Click Here](https://www.cns.ford.com/AD/TICKET_INFO/)|
|LBaaS|jpowers2|BMC- Network Service|
| NaaS|jpowers2|BMC- Network Service|
| Nexus|rkidd4|[Click Here](http://www.request.ford.com/RequestCenter/myservices/navigate.do?query=orderform&sid=294&layout=&) and application search - Nexus|
|vRealize Automation|sjoshi16|[Click Here](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/)|
|vSphere|gfilipow|[Click Here](http://www.request.ford.com/RequestCenter/myservices/navigate.do?query=orderform&sid=289&layout=&userid_for_service_search=19022&)|
|Vault|kcardwel|TBD|

<a name="prod"></a>
### PROD Integration Endpoints

| Service Name | Description | Endpoint URL|
|----------|---------|---------|
| Active Directory | Active Directory plug-in to connect to a running Active Directory instance and manage users and user groups, as well as Active Directory computers, organizational units, and so on| ldap://fmcford01.ford.com:389|
| NaaS Host | HTTP-REST Endpont provides Hostname and IP solutions|https://iwf.fhc.ford.com/mgmt/ford/sc/host/|
| LBaaS GSLB | HTTP-REST Endpont provides Load-balancing solutions|https://iwf.fhc.ford.com/mgmt/ford/sc/gslb/|
|gMSA|HTTP-REST Endpoint provides ability to provision or unprovision gMSA service acocunts in Active Directory| https://ito11612.hosts.cloud.ford.com/api/gmsa|
| BMC| HTTP-REST Endpoint provides CMDB solutions like CI creations, Support group queues creations|https://www.arintegration.ford.com:8443|
|Habitat Supervisor| HTTP-REST Endpoint| http://ito000604.fhc.ford.com|
|Vault | HTTP-REST Endpoint |http://19.14.3.13|
| API Connect| HTTP-REST Endpoint| https://apigtw.ford.com/|
|Nexus | HTTP-REST Endpoint| https://www.nexus.ford.com|
| vSphere - EDC1 - H12| Plug-in| https://apl12002.prod.f01.dc1.ford.com:443/sdk|
| vSphere - EDC1 - H1| Plug-in| https://apl11002.prod.f01.dc1.ford.com:443/sdk|
| vSphere - ECC | Plug-in| https://apl10021.fhc.ford.com:443/sdk|
|vRealize Automation| Plug-in|https://vra.cloud.ford.com/|
|vAPI| Plug-in| https://apl11002.prod.f01.dc1.ford.com/api|
|vAPI| Plug-in| https://apl12002.prod.f01.dc1.ford.com/api|
|vAPI| Plug-in| https://apl10021.fhc.ford.com/api|

<a name="preprod"></a>
### PrePROD Integration Endpoints

| Service Name | Description | Endpoint URL|
|----------|---------|---------|
