# Service Operating Model

Cloud Automation Engineering will serve as a single support team made up of Planning, Engineering, and Operations that provide a standard set of vRA Cloud Management Platform service offerings that meet key business requirements.

vRealize Automation (vRA) is the Ford Engineered Cloud Automation platform. This platform is utilized for developing, deploying and managing IaaS services in Next Generation Data Center.

The operating model is aligned with Ford ITOM, DevOps Framework and Agile Methodologies. We follow the Ford Standard sets of processes and tools to manage the life cycle of vRA Platform services.

## ITMS 
|   Application  | ID |
|----------|---------|
|vRealize Automation| 50400|
|vRealize Orchestrator|50401|

## Communication Plan

|   Communication Tools   | Purpose |
|----------|---------|
| [Flowdock Channel](https://www.flowdock.com/settings/ford/flows/vra-vro-platform-buildout)|Reporting outages|
| ITO_NG_CLOUD_AUTOMATION@bulkmail.ford.com | See below ([Subscribe to bulkmail list](http://bulkmail.ford.com/~bulkmail/Subscriptions.cgi?list=Z0074207))|
|[CMOS](http://www.tcs.ford.com/cmos/cmos.asp)- ITO PRODUCT SERVICE SUPPORT - CLOUD AUTOMATION - VRA VRO - **GLOBAL CLOUD AUTOMATION ENGINEERING**|On-Call list for weekend critical tickets|

Purpose of the bulkmail list above is to communicate the following to all vRA Portal users:

- vRA/vRO Platform outages
- Platform changes/Upgrades
- Platform Releases
- Other critical notifications for wider audience/user groups regarding the Platform.


## Processes
- [Incident Management](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/processes/Incident_management.md)
- [Request Fulfilment](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/processes/request_fulfilment.md)
- [Change Management](https://github.ford.com/CloudAutomation/Change-Management)
- [Problem Management](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/processes/Problem_management.md)
  
##### To be launched
- [Event Management](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/processes/event_management.MD)
- [Knowledge Management](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/vRA%20Operations%20Index%20Guide.md)
- Release Management
- [SACM](https://github.ford.com/SDDC/Infrastructure/tree/master/releases/components/vrealize-automation/deployments)

## Tool sets

| Processes |Tactical|Long-Term|
| :--- | :--- | :--- | 
|Incident Managment| BMC (Old)|NG BMC|
|Requests fulfilment| Request Center | NG BMC|
|Change Management| GitHub| GitHub and NG BMC|
|Problem Management | BMC (Old) & Rally (Defects)| NG BMC & Rally (Defects)|
|Knowledge Management|GitHub|GitHub|
| SACM| FCAMS (Old) | uCMDB|
| Release Management| GitHub|GitHub|
|Event Management| Email from vROps & vRLI|BMC (Netcool)|

## Desk Procedures
- [Platform Deployment](https://github.ford.com/SDDC/Infrastructure/tree/master/releases/components/vrealize-automation/install)
- [Password Management](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/PasswordManagement.md)
- [Platform DR Procedure](https://github.ford.com/SDDC/Infrastructure/tree/master/releases/components/vrealize-automation/disaster-recovery)
- [Operational Documents](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/vRA%20Operations%20Index%20Guide.md)
