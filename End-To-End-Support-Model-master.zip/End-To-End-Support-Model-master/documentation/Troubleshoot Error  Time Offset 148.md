## Steps for Troubleshoot the " Error Time offset 148.

### Objectives:

- Environment time sync is properly happen in VRA/VRO environment.

### Impacted Configuration Items

- vRealize Automation
- vRealize Orchestrator


### Troubleshooting Steps:

1)      Login to the VRAppliance and Go to VRA setting-Cluster tab in pre-production vRA Utility(MMR100005/6) server. 

3)     Noticed the status as "Troubleshoot Error: Time Offset "-148 seconds" you will need to change this                    setting. Because this will  cause unpredictable behavior of the Environment.

4)      For changing this setting, log into Vcenter (Aplvc0012) via web client

5)      Choose the pre-prod VRA utility server (MMR100005) and verify the time sync status

6)      Choose the Edit setting->VMtools->Synchronize Guest time with host.

7)      Enable the sync option and verified the Cluster tab status "Time offset 148 error has disabled”.
