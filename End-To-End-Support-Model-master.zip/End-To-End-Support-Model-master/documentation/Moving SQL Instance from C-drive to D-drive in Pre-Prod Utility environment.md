## Steps for moving SQL Instance from C-drive to D-drive in Pre-Prod Utility environment

### Objectives:

- Moving SQL Instance from C-drive to D-drive in Pre-Prod Utility environment

### Impacted Configuration Items

- vRealize Automation


Steps:

1. Take the snapshot for VRA components (VRAappliance, VRAmanager ,etc) before star the activity

2. Stop the VRA services start with VMware (running)

3. Login into Visual studio choose Database->VRA->Right click->task->detach and disconnect the DB

4. Run the query "select * from sys.master_files" from SQL query console and find the path

5. Move the DB from one location to destination location

6. Choose the Database->VRA->Right click->task->attach and connect the DB

7. Start the VRA services, which we stopped before start the activity

8. Login into VRA appliance and verify all the services are started

9. Provision a test VM from VRA to verify the functionality.
