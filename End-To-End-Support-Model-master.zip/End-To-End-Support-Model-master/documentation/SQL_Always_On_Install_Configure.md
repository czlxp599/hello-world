Activity: VRA IAAS SQL AAG configuration 

• Before move the DB, we have taken snapshot entire stack
• VRA/VRO and SQL platform team has moved DB from standalone to Cluster nodes. Post moved into     DB some of the services has started.
• Services like : Proper communication does not happen IIS and appliance servers
• Logged into VRA appliance and started the respective services(ex: Vcloud automation service)
• As per VMware recommendation service configuration only applicable for 7.3

MSDTC Issue

• Post the database change, we had another issue Microsoft distributed transaction coordinator  
  (MSDTC). The only change performed was SQL nodes. We have 2 SQL nodes in always on.
• We decided to perform a MSDTC install on the primary SQL node. After performing a failover of  
  DB to secondary node, vRA had no issues at all. 
• Ref Url : 
  https://blogs.vmware.com/management/2017/03/troubleshooting-vrealize-automation-ms-dtc.html
• Ford to check after failing over database to primary server and see if it's all clean without 
  any errors

VRO DB Migration
•	When performing vRO SQL DB change in a clustered environment, cluster would be in inconsistent state, so we need join the second node to the first one(active) 
•	After performing it, it's all in consistent state
