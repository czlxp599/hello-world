## Change/Update Service Accounts in vRA/vRO environment:

# Purpose

This article provides steps to change the VMware vRealize Automation (formerly known as VMware vCloud Automation Center for Server) Service Account passwords.

# Service/Proxy Account Reset:

Steps outlined below are generic irrespective of the services:

1. Standard Change records should be created at least 10 days in advance.
2. Check out the current service/proxy accounts from Vault System.
3. Schedule maintenance mode for the appliances/machines to ensure alerts are not triggered.
4. Set the proxy account password. Browse to https://www.changepassword.ford.com and log on    using the proxy ID and password. Change the password. If this fails, use the PIN and securit question to reset it (if available), or contact management.
5. Update the passwords in the vault systems WITHOUT FAIL.

Once the above steps are completed, please navigate below to update respective services.

Below are the components/services configured with proxy/service accounts in Ford VRA/vRO environment:

  1. Reset root password in vRA 7.x
  2. Iaas Host Serivce Account
  3. vRA vCenter Endpoint Service Account
  4. Powershell Serivce Account
  5. Identity Connectors Serivce Account
  6. AD Ldap Service Account
  7. vRO vcac Service Account
  8. Jenkins Serivce Account
  9. Management Cluster vRA Endpoint Service Account (For all teanants)

Click on the respective documentation for its specific procedures.

# 1. Reset root password in vRA 7.x (Refer:https://kb.vmware.com/s/article/2150647)

# Notes:

 In vRealize Business, the root password does not expire. This KB article still applies if the user does not remember the password.

 You will not have access to SSH and VAMI interface (5480) without root password. vRA root password expires automatically after 365 days   and admins may not be aware of it.

# Procedures:

To reset the root password:

 - Connect to vSphere Client and open the vRA/vRB virtual machine console.
 - Go to VM > Power > Restart Guest to restart the appliance.
   Wait for the virtual machine to reboot.
 - Press e when you see the Grub Menu appearing on the screen.
 - Press e again.
 - Go down until you see a line beginning with linux /vmlinuz.
 - At the end of this line, add the command:

       init=/bin/sh
       
 - Press " F10" to reboot. 
 - Type the command passwd to reset the root password. Enter 'New Password & Confirm New Password'
 - After a reboot, you should be able to access the VAMI interface with the new password you just set.


# 2. Iaas Host Serivce Account (Refer:https://kb.vmware.com/s/article/2099949)

# Notes:

To change the vRealize Automation (formerly known as VMware vCloud Automation Center for server) IaaS Service Account or Service Account password, update all IIS instances as well as vRealize Automation Manager Service, DEM, and Agent services.

# Procedures:

Prepare the environment for the update:

1. Stop the IIS on all vRealize Automation web servers.
2. Stop all vRealize Automation Services on all servers.

Update the IIS Application Pools:

1. Log in to IIS on all vRealize Automation web servers and click Application Pools.
2. Right click each vRealize Automation Application Pool and select Advanced settings.
3. Update the local administrators group in Windows with the updated Service Account (if    applicable).
4. Update the Identity to the new Service Account and/or Password.
5. Save and close any open IIS windows.
6. Update the local administrators group in Windows with the updated Service Account (if    applicable).

Update the vRealize Automation service accounts:

1. Log in to each vRealize Automation services servers. This includes DEMs, Agents,     
   Manager Service servers.
2. Open Windows Services.
3. Right click each vRealize Automation service and choose properties.
4. Update the Log On as account for each service to reflect the new Service Account 
   and/or Password.
5. Update the local administrators group in Windows with the updated Service Account (if 
   applicable).

Update SQL Database permissions for the IaaS database:
If you have changed the account associated with the Repository application pool, ensure these:

1. Log in to SQL Server Manager Studio.
2. Change or Add a new vRealize Automation IaaS service account as a dbo of the IaaS   
   database.

Complete the updates:

1. Start IIS on all web servers.
2. Start vRealize Automation services on all servers except any cold/ standby manager  
   service services as you can only have one of these running at a time.

Note: Ensure to only start one vRealize Automation manager service if you have an HA or        distributed environment and confirm that only one of the vRealize Automation manager services are configured to start automatically.

# 3. vRA vCenter Endpoint Service Account

# Notes:

To change the vRealize Automation (formerly known as VMware vCloud Automation Center for server) vCenter Endpoint Service Account password, you need to ensure the service account has the appropriate level of access configured in vCenter.

## For vRA 7.2:

 1. Login to vRA (vCAC) and click on “Infrastructure” tab.
 2. Navigate to “Endpoints” -> “Credentials”
 3. Click the pencil icon next to the Endpoint credential that you want to edit (e.g. the one that was changed)
 4. Enter and confirm the new service account password
 5. Click the green check mark icon to save
 
## For vRA 7.4: 

 1. Login to vRA (vCAC) and click on “Infrastructure” tab.
 2. Navigate to “Endpoints” -> Select the Endpoints you want to update the password.
 3. Click the pencil icon.
 4. Verify the Endpoint and Service Account details.
 5. Enter and confirm the new service account password in the password field.
 6. Click the "Test Connection" and it should prompt "Test Connection was successful" 
 5. Click OK.

