### Password Management Using PAR

  vRA/vRO Service Accounts are managed through PAR Password Managament system.
  
  This document provides collection details and documentation link for retrieving Service Accounts password from PAR system.
  
#### PAR Collection Details

  vRA/vRO root and Service Accounts are maintained in a PAR Collection "GL_VRA_NG_Clud_ISA_DigEnv_Grp". Cloud Automation Team has access to   this collections to retrieve root/Service Accounts.
  
#### Usage Instructions

  Our PAR Collection is configured to trigger Approval Flow whenever an account is retrieved. 
  Requester can view the passwords upon approval by one of the approvers. 
  
 #### Approvers
  
  Sanjeev, Jim and Natchi are set as Approvers for "GL_VRA_NG_Clud_ISA_DigEnv_Grp" digital envelope.
  
#### PAR Documentation (For Password Checkout):
  
  Here is the document for retrieving Password's from PAR: [PAR Tool User Guide](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/Password%20Checkout%20Procedure.DOCX)
  
  For more information on PAR, you can refer [PAR Digital Envelopes](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/PAR%20Digital%20Envelopes.pptx)
