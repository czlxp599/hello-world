## vRA/vRO Operational Guide

## Table Of Contents

## Overview 

   vRA/vRO Operations is the Ford Automation platform. This platform is utilized for deploying services into the datacenter.

   VRA/VRO Operations will be handled by the ESXi-Ops and VRA Platform Team. This extends to aspects related to the platform itself, not 
   related services that are consumed by VRA/VRO (NAAS, Automated OS, etc.)

## Documentation

  - Documentation Guidelines
  - [Document List/Status](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/Document%20List_Status.md)

## vRA/vRO Team Contact Information

  - [CMOS Group - (ITO PRODUCT SERVICE SUPPORT - VRA PLATFORM - GLOBAL VRA)](http://www.tcs.ford.com/cmos/cmos.asp)
  
## Environments

 - Production
 - Pre-Production
 - Old-Production
 
## Process Documentations

 - Onboarding Kit & Knowledge Transition
 - [vRA SandBox Access](https://github.ford.com/CloudAutomation/vra-sandbox-service)
 - [vRA Production Access](https://github.ford.com/BSARAV20/End-To-End-Support-Model/tree/master/access)
   - [vRA Role and Access Management](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/auth/vra-Access-Management.md)
 - vRA Architecture in FORD
     - [vRA Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/vRA-infra-alignment-current.vsd)
     - [vRA Tenant](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/vRA-Tenant-Arch.vsd)
     - [vRealize Automation Artifacts](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/README.md)
 - Service Level Agreement (SLA) for vRA/vRO
 - Service Level Agreement (SLA) for vROPS
 - Duties and Responsibilities  
 - On Call Duties
 - [Server Naming Standard for NextGen](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/documentation/NamingStandards.MD)
 - Engineering Team Engagement (For Escalation Support)
 - [Handling Issues/Requests](https://github.ford.com/BSARAV20/End-To-End-Support-Model/tree/master/open-git-issue)
 - [Change Management](https://help.github.com/articles/creating-a-pull-request)
 - [Password Management](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/PasswordManagement.md)

## Technical Procedures

 - vRA Appliance Installation/Configuration (Single/Distributed Deployment)
     - [vRA Appliance Install Document](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealizeautomation/install/VRA%20%26%20VRO%207.4%20%20Built.md)
     - [vRA Powershell Host Install/Configure Document](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/documentation/PowerShell%20Host%20configuration.docx)
     - [SQL Always-On Configuration](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/SQL_Always_On_Install_Configure.md)
 - [Integrating vRA with LogInsight](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/install/loginsight-integration.md)
 - [vRealize Load Balancing in Ford](https://github.ford.com/SDDC/Infrastructure/tree/master/releases/components/vrealize-automation/load-balancing)
 - [High Availability - Three Node Cluster Deployment](https://github.ford.com/SNARLA1/vRAThreeNode/blob/master/vRAThreeNodes.md)
 - [Patch Installation Guide](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/documentation/vRealize%20Automation%20Appliance%20%E2%80%93%20Patch%20installation%20Procedure.md)
 - [vRealize Environment Backups](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/backup/backup-request-template.md)
 - Upgradation Guide
 - [SSL Certificate](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/install/Signing_vRA_certificates.md)
 - [Service/Proxy Account Updation](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/documentation/vRAvRO-ProxyAccountUpdate.md)
     - [vRA/vRO Service Account Requirements](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/auth/vra-vro-account-strategy.md)
     - [vRA/vRO Service Account Usage Chart](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/auth/vra-accounts-connections.pdf)
 - Troubleshooting vRA/vRO issues

## vRealize Monitoring

 - [Monitoring the environment](https://github.ford.com/BSARAV20/End-To-End-Support-Model/tree/master/monitoring)
 - Monitoring the Reservations
 - Reporting (Using vROPS/Health Monitoring Reports)

## Disaster Recovery

 - DR Testing Procedure
 - [HA Failover Procedure](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/HA%20DR%20Procedure.md)
 - vRA/vRO Failover Procedure
 - Restoration Process for vRA/vRO Appliance



