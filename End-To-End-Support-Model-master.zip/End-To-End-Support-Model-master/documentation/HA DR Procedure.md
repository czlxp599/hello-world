## HA Failover Test

## Purpose and assumption

This document provides step-by-step instructions for HA DR failover

### Procedure for HA

### Appliance Test: 

1) Move the Database to secondary Appliance and restart primary appliance and test.
  - Login to primary vRA applaince --> Database tab --> promote secondary appliance DB as primary.
  - Login to primary applaince --> Execute reboot command.
  - Validate all vra.cloud.ford.com configuration
   
2) Move back the Database to primary applaince and reboot secondary appliance

 - Once all the services are started in Primary node --> login to secondary appliance console --> Database --> Reset the database 
   promote database to primary node
 - Reboot secondary node and test.
 - Validate all vra.cloud.ford.com configuration

### Web Service test: 

### Primary Web server:

- Shutdown primary mgr server and check Mgr site is up.
- Test whether the traffic is going through secondary web server.

### Secondary Web server:

- Shutdown Secondary mgr server and check mgr site is up.
- Test whether the traffic is going through secondary web server.

### Manager Server: 

### Primary Mgr Server:

- Shutdown primary mgr server and check vramgr.cloud.ford.com site is up and check the DEM orchestrator status --> Infrastructrue --> Monitor --> DEM orchestrator status --> Secondary should be online.
- Test whether the traffic is going through secondary web server.

### Secondary Web server:

- Shutdown Secondary mgr server and check vramgr.cloud.ford.com site is up and check the DEM orchestrator status --> Infrastructrue --> Monitor --> DEM orchestrator status --> Primary should be online.
- Test whether the traffic is going through primay sever web server.

### DEM Worker: 

- Shutdown Dem worker one by one and test the status in  Infrastructrue --> Monitor --> Dem status (should be offline)
- Please follow the same procedure for all DEM workers.
Once test is done start the DEM workers.

### Agents: 

- Shutdown Primary Agent server and check the Agent status under Infrastructre --> computer resurces --> Agent status (Agent status should be online)
- Shutdown Secondary Agent server and check the Agent status under Infrastructre --> computer resurces --> Agent status  (Agent status should be online)
