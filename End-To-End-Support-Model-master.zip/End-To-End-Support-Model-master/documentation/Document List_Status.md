|	Document Type	|	Description 	|	Repository	|	Status	|	Support Required |
|---------------|---------------|-------------|---------|------------------|
|	Process	|	Documentation Guidelines	|	TBD	|	Started	|	No |
|	Process	|	CMOS	|	[CMOS Link](http://www.tcs.ford.com/cmos/cmos.asp)	|	Completed	|	No |
|	Process	|	Environments	|	TBD	|	Started	|	No |
|	Process	|	Onboarding Kit & Knowledge Transition	|	TBD	|	Not Started	|	Yes |
|	Process	|	vRA SandBox Access	|	[CloudAutomation](https://github.ford.com/CloudAutomation/vra-sandbox-service)	|	Completed	|	No |
|	Process	|	vRA Production Access	| [CloudAutomation](https://github.ford.com/BSARAV20/End-To-End-Support-Model/tree/master/access) | Completed	|		No |
|	Process	|	vRA Role and Access Management	|	[SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/auth/vra-Access-Management.md)	|	Completed	|	No |
|	Process	|	vRA Architecture in FORD --> vRA Infrastructure	|	[SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/vRA-infra-alignment-current.vsd)	|	Completed	|	No |
|	Process	|	vRA Architecture in FORD --> vRA Tenant	|	[SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/vRA-Tenant-Arch.vsd)	|	Completed	|	No |
|	Process	|	vRA Architecture in FORD --> vRealize Automation Artifacts	|	[SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/README.md)	|	Completed	|	No |
|	Process	|	Service Level Agreement (SLA) for vRA/vRO	|	TBD	|	Not Started	|	Yes |
|	Process	|	Service Level Agreement (SLA) for vROPS	|	TBD	|	Not Started	|	Yes |
|	Process	|	Duties and Responsibilities	|	TBD	|	Not Started	|	No |
|	Process	|	On Call Duties	|	TBD	|	Not Started	|	No |
|	Process	|	Server Naming Standard for NextGen	| [CloudAutomation](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/documentation/NamingStandards.MD)	|	Inprogress	|	Yes |
|	Process	|	Engineering Team Engagement (For Escalation Support)	|	TBD	|	Not Started	|	Yes |
|	Process	|	Handling Issues/Requests	|	[CloudAutomation](https://github.ford.com/BSARAV20/End-To-End-Support-Model/tree/master/open-git-issue)	|	Inprogress	|	Yes |
|	Process	|	Change Management	|	[GitHubGeneral](https://help.github.com/articles/creating-a-pull-request)	|	Inprogress	|	Yes |
|	Process	|	Password Management	|	[CloudAutomation](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/PasswordManagement.md)	|	Completed |	No |
|	Technical	|	vRA Appliance Install Document |	[SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealizeautomation/install/VRA%20%26%20VRO%207.4%20%20Built.md) |	Completed	|	No |
|	Technical	|	vRA Powershell Host Install/Configure Document	|	[CloudAutomation](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/documentation/PowerShell%20Host%20configuration.docx) |	Completed	|	No |
|	Technical	|	SQL Always-On Configuration	|	[CloudAutomation](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/SQL_Always_On_Install_Configure.md)	|	Completed	|	No |
|	Technical	|	Integrating vRA with LogInsight	| [SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/install/loginsight-integration.md)	|	Completed	|	No |
|	Technical	|	vRealize Load Balancing in Ford	| [SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/tree/master/releases/components/vrealize-automation/load-balancing) |	Completed	|	No |
|	Technical	|	High Availability - Three Node Cluster Deployment	| [Link](https://github.ford.com/SNARLA1/vRAThreeNode/blob/master/vRAThreeNodes.md)	|	Completed	|	No |
|	Technical	|	Patch Installation Guide	|	[CloudAutomation](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/documentation/vRealize%20Automation%20Appliance%20%E2%80%93%20Patch%20installation%20Procedure.md)	|	Completed	| No |
|	Technical	|	vRealize Environment Backups	|	[SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/backup/backup-request-template.md)	|	Completed	|	No |
|	Technical	|	Upgradation Guide	|	TBD	|	Not Started	|	No |
|	Technical	|	SSL Certificate	|	[SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/install/Signing_vRA_certificates.md)	|	Completed	|	No |
|	Technical	|	Service/Proxy Account Updation	|	[CloudAutomation](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/documentation/vRAvRO-ProxyAccountUpdate.md) |	Completed	|	No |
|	Technical	|	vRA/vRO Service Account Requirements	|	[SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/auth/vra-vro-account-strategy.md)	|	Completed	|	No |
|	Technical	|	vRA/vRO Service Account Usage Chart	| [SDDC/Infrastructure](https://github.ford.com/SDDC/Infrastructure/blob/master/releases/components/vrealize-automation/auth/vra-accounts-connections.pdf)	|	Completed	|	No |
|	Technical	|	Troubleshooting vRA/vRO issues	|	[CloudAutomation](https://github.ford.com/CloudAutomation/End-To-End-Support-Model/blob/master/documentation/vRA%20Troubleshooting.md)	|	Completed	|	No |
|	Monitoring	|	Monitoring the environment	| [CloudAutomation](https://github.ford.com/BSARAV20/End-To-End-Support-Model/tree/master/monitoring)	|	Inprogress	|	No |
|	Monitoring	|	Monitoring the Reservations	|	TBD	|	Not Started	|		 |
|	Monitoring	|	Reporting (Using vROPS/Health Monitoring Reports)	|	TBD	|	Not Started	|		 |
|	DR Testing	|	DR Testing Procedure	|	TBD	|	Not Started	|		 |
|	DR Testing	|	vRA/vRO Failover Procedure	|	TBD	|	Not Started	|		 |
|	DR Testing	|	Restoration Process for vRA/vRO Appliance	|	TBD	|	Not Started	|		 |
| DR Testing  | HA Failover Testing | [CloudAutomation](https://github.ford.com/PANGAPPA/End-To-End-Support-Model/blob/67e31848724b108b7119583dde7a373fa8964c7f/documentation/HA%20DR%20Procedure.md) | Inprogress | Yes
