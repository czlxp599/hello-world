# 7.4 Install

Deploy Windows 2016 core

- [hplab1_repository] IMAGES/windows/iso/en_windows_server_2016_x64_dvd_9718492.iso
- https://www.gsoutils.ford.com/images/microsoft/windows_server_2016/standard/iso/en_windows_server_2016_x64_dvd_9718492.iso

setup network config (including time server)
    setup proper DNS suffix
    NV Domain registry key
    setup time.ford.com time server
install iis

https://support.pkware.com/display/SMAR/Windows+Server+Core+Installation+and+Setup+Guide

```Powershell
Install-WindowsFeature -name Web-Server -IncludeManagementTools
install-windowsfeature web-windows-auth
## not needed:  install-windowsfeature NET-Framework-Core -Source D:\sources\sxs

dism /online /enable-feature /featurename:netfx3
list of feature names along with the UI name:  
https://social.technet.microsoft.com/Forums/en-US/4f8b0ec0-10d9-4378-b016-559b9b72fb77/windows-server-2016?forum=wflmgr

   https://powershell.org/2014/01/01/using-install-windowsfeature-with-offline-source/
install-windowsfeature Web-Asp-Net45

```

## Download and Install SQL

```Powershell
Invoke-WebRequest -Uri "http://fsilws10.fsillab.ford.com/files/coreapps/MSSQL/Standard/SQL2016STD.zip” -OutFile "C:\path\file"
Expand-Archive SQL2016STD.zip -DestinationPath "C:\Users\Administrator\downloads\"
```


download and install management agent
    https://vra02.nlsa.nglab.ford.com:5480/installer/vCAC-IaaSManagementAgent-Setup.msi

```Powershell
Invoke-WebRequest -Uri "http://fsilws10.fsillab.ford.com/files/coreapps/vra/7.4/vCAC-IaaSManagementAgent-Setup.msi" -Outfile "C:\Users\Administrator\downloads\vCAC-IaaSManagementAgent-Setup.msi"
```

## Install Management Agent (on IaaS server)

.\vCAC-IaaSManagementAgent-Setup.msi
C:\program files (x86)\VMware\vCAC\Management Agent\ (default location)
vra appliance address:  https://vra02.nlsa.nglab.ford.com:5480
root username:  root
passowrd:  Ford!vra74
Management Site Service certificate SHA1 fingerprint - click load

Management Agent Configuration
Username: vra01\administrator
password:  vagrant

## Run installation wizard
https://vra02.nlsa.nglab.ford.com:5480/

- Minimal Deployment
- Install Infrastructure as a Service
- Fix

# Wizard
vRealize Automation Host:  vra02.nlsa.nglab.ford.com
Single Sign-on: admistrator@vsphere.local / Ford!admin74
IaaS Host:
- IaaS Web address: vra01.nlsa.nglab.ford.com
- Install Components on:  vra01.nlsa.nglab.ford.com
- Username:  vra01\administrator 
- password:  vagrant
- Security Passphrase: Ford!IaaS

# Microsoft SQL Server
- Server name: vra01.nlsa.nglab.ford.com
- Database name:  vra
- Create new
- Default settings
- Windows authentication

# Distributed Execution Managers
- hostname: vra01.nlsa.nglab.ford.com
- Instace Name: DEM
- Username: vra01\administrator
- Passsword:  vagrant
- Instance Description: DEM
- Installation Path:  blank

# Agents
- IaaS Host name:  vra01.nlsa.nglab.ford.com
- Agent name:  vCenter
- Endpoint: vCenter
- Installation Path: blank
- Agent Type: vSphere
- Username: vra01\administrator
- Password: vagrant


# vRealize Appliance Certificates
- Certificate Action: Generate Certificate
- Common Name: vra02.nlsa.nglab.ford.com
- Organization: Ford Motor Company
- Organizational Unit:  ITO
- Country Code:  US

Save generated certificate

# Web Certificate
- Certificate Action: Generate Certificate
- Common Name: vra01.nlsa.nglab.ford.com
- Organization: Ford Motor Company
- Organizational Unit:  ITO
- Country Code:  US

Save generated certificate

# Validation
- Validate

# Snapshots
- Take snapshots of all servers (incl appliance)

# Installation Details
- Install


# Licensing
License key is updated successfully.
Licensing
Help
Enter a new license key for vRealize Automation, vRealize Code Stream, or vRealize Business. You can enter multiple license keys, one at a time.
New License Key
 
Select the check box to have this appliance run vRealize Code Stream. vRealize Code Stream does not currently support High Availability (HA) configurations and should not be enabled on a vRealize Automation production system, particularly if it is configured in HA mode. For details, see the vRealize Code Stream Reference Architecture guide.
Enable vRealize Code Stream
       
Submit Key

License Type vRA Suite License
Product Name VMware vRealize Suite 7 Enterprise
Product Version 7.0
Suite Name VMware vRealize Suite 7 Enterprise
Product Family VMware vCloud Automation Center
Licensable Capacity PLU License - 44 CPU Packages or 660 Desktop VMs or 660 Server VMs
License Key XM43Q-4AK5J-481AT-0E202-00T35
Expires never

 
# Initial Content Creation:
Create a configuration admin user to request the Initial Content workflow. This workflow appears in the service catalog for the user.
Administrator username: configurationadmin
Password:  Ford!admin74
 
 
Your input for this installation has been saved in /usr/lib/vcac/tools/install/ha.2018-04-20_23.58.29.properties . You can use this properties file to perform silent installation for this environment.
