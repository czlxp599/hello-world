## vRealize Automation Appliance Patch Installation

  This article contains a list of known issues that are resolved in the latest patch available for vRealize Automation 7.x.
  vMware releases vRA patches and it can be located in the link below:
   
## Pre-Requisites:

 - Take Virtual Machine/Appliance Snapshots (For Backup Requirements) 
 - Verify that all nodes in your vRealize Automation installation are up and running.
 - If your environment uses load balancers for HA, disable traffic to secondary nodes and disable service monitoring
    until after installing or removing patches and all services are showing REGISTERED.
 - Download the patch file from [vMware vRealize Download Page](https://my.vmware.com/web/vmware/details?downloadGroup=VRA-
    740&productId=676&rPId=24602#product_downloads)
 - Downloaded patches will have an extension *.patch.

 ## Installation Steps:
  
   Once the patch is downloaded, patch file should be mapped to vRealize Appliance following below steps:
  
1. Login to vRA Appliance Administrator Console (https://vRA-URL:5480)\

   ![alt text](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/Images/Patch1.jpg)
      
      Login into Master Node's VAMI page
      Click on vRA Settings -> Patches
      
   ![alt text](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/Images/Patch2.jpg)   

   Note : To enable or disable Patch Management, log in to the vRealize Automation appliance using the console or SSH as root, 
           and enter one of the following commands:

          /opt/vmware/share/htdocs/service/hotfix/scripts/hotfix.sh enable /opt/vmware/share/htdocs/service/hotfix/scripts/hotfix.sh    
          disable

2. Click on upload patch, select location and upload.
3. Click on New Patch and hit Upload Patch.
4. Map the latest patch file (*.patch) downloaded from vmware site.

    ![alt text](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/Images/Patch3.jpg)
  
5. Once upload is complete it would give you an option to install the patch.
   Remember do not refresh the page once you start an upload , just wait till it completes
   
    ![alt text](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/Images/Patch4.jpg)
  
6.  Click on "INSTALL" to start installation of patch

    ![alt text](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/Images/Patch5.jpg)
  
  Click on the check box "I have performed all required manual pre-requisite steps" and hit Install.
  
   ![alt text](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/Images/Patch6.jpg)
  
  Now, the status will show as "Installing"
  
    ![alt text](https://github.ford.com/BSARAV20/End-To-End-Support-Model/blob/master/Images/Patch7.jpg)
  
7.  Once Installed, status should change to "Success.Install Complete"
8.  We can check what patches are installed by browsing through "Installed Patches" section

## Post Installation Procedures

1. Verify if all services are in "REGISTERED" state on all nodes.
2. Re-enable LB traffic to secondary nodes.
3. Finish testing by provisioning few workloads, once done consolidate snapshots taken during pre-requisites check
